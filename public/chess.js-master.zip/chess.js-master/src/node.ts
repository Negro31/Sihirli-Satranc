export type Node = {
  move?: string
  suffixAnnotation?: string
  nags: string[]
  comment?: string
  variations: Node[]
}
